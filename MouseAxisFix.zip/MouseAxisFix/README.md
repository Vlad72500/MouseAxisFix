# Mouse Axis Fix (діагностична версія)
Діагностика осей USB-миші + експериментальні спроби вплинути на поворот.
Не є повноцінним виправленням GeForce NOW: без Root перехопити події миші чужого застосунку неможливо.
Збірка: GitHub Actions (.github/workflows/build.yml) -> Artifacts -> MouseAxisFix-apk.
