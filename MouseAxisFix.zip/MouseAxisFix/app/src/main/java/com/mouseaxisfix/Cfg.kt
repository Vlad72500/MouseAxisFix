package com.mouseaxisfix

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration

object Cfg {
    val PROFILES = listOf("Стандартний Android", "GeForce NOW", "Користувацький")
    val AXES = listOf("X→X, Y→Y", "X→Y, Y→X", "Інверсія X", "Інверсія Y", "Інверсія X і Y")
    val ROTS = listOf("0°", "90° за годинниковою", "180°", "270° за годинниковою")
    val ORIENT_MODES = listOf("Автоматично", "Завжди портретний профіль", "Завжди альбомний профіль")

    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("maf", Context.MODE_PRIVATE)
    }

    var profile: Int
        get() = sp.getInt("profile", 0)
        set(v) { sp.edit().putInt("profile", v).apply() }

    var orientMode: Int
        get() = sp.getInt("orientMode", 0)
        set(v) { sp.edit().putInt("orientMode", v).apply() }

    private fun key(p: Int, land: Boolean, n: String) = "${n}_${p}_${if (land) 1 else 0}"
    fun axes(p: Int, land: Boolean) = sp.getInt(key(p, land, "a"), 0)
    fun rot(p: Int, land: Boolean) = sp.getInt(key(p, land, "r"), 0)
    fun setAxes(p: Int, land: Boolean, v: Int) { sp.edit().putInt(key(p, land, "a"), v).apply() }
    fun setRot(p: Int, land: Boolean, v: Int) { sp.edit().putInt(key(p, land, "r"), v).apply() }
    fun reset() { sp.edit().clear().commit() }

    /** Який профіль орієнтації активний (з урахуванням ручного вибору). */
    fun landscape(c: Context): Boolean = when (orientMode) {
        1 -> false
        2 -> true
        else -> c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    /** Перетворення вектора руху (dx, dy): спочатку осі, потім поворот. */
    fun transform(dx: Float, dy: Float, axes: Int, rot: Int): Pair<Float, Float> {
        var x = dx
        var y = dy
        when (axes) {
            1 -> { x = dy; y = dx }
            2 -> { x = -dx }
            3 -> { y = -dy }
            4 -> { x = -dx; y = -dy }
        }
        val ox = x
        val oy = y
        return when (rot) {
            1 -> Pair(-oy, ox)
            2 -> Pair(-ox, -oy)
            3 -> Pair(oy, -ox)
            else -> Pair(ox, oy)
        }
    }
}
