package com.mouseaxisfix

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.app.AlertDialog
import android.hardware.input.InputManager
import android.view.InputDevice
import android.view.Surface
import android.view.WindowManager

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.button(text: String, color: Int = 0xFF2D6CDF.toInt(), onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 18f
        setTextColor(Color.WHITE)
        minimumHeight = dp(56)
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(color)
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(6), 0, dp(6)) }
    }

fun Context.label(text: String, size: Float = 16f, color: Int = 0xFFE0E0E0.toInt()): TextView =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        setPadding(0, dp(4), 0, dp(4))
    }

fun Context.column(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(16), dp(16), dp(16), dp(16))
}

fun Activity.pick(title: String, items: List<String>, cur: Int, onPick: (Int) -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setSingleChoiceItems(items.toTypedArray(), cur) { d, i -> onPick(i); d.dismiss() }
        .show()
}

fun Context.mice(): List<InputDevice> =
    InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }
        .filter { it.supportsSource(InputDevice.SOURCE_MOUSE) && !it.isVirtual }

@Suppress("DEPRECATION")
fun Context.displayRotationText(): String {
    val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    return when (wm.defaultDisplay.rotation) {
        Surface.ROTATION_0 -> "0°"
        Surface.ROTATION_90 -> "90°"
        Surface.ROTATION_180 -> "180°"
        else -> "270°"
    }
}

fun Context.orientationText(): String =
    if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
        "Альбомна" else "Портретна"

fun sourceName(s: Int): String {
    val parts = ArrayList<String>()
    fun has(m: Int) = (s and m) == m
    if (has(InputDevice.SOURCE_MOUSE_RELATIVE)) parts.add("MOUSE_RELATIVE")
    else if (has(InputDevice.SOURCE_MOUSE)) parts.add("MOUSE")
    if (has(InputDevice.SOURCE_TOUCHSCREEN)) parts.add("TOUCHSCREEN")
    if (has(InputDevice.SOURCE_TOUCHPAD)) parts.add("TOUCHPAD")
    if (has(InputDevice.SOURCE_STYLUS)) parts.add("STYLUS")
    if (parts.isEmpty()) parts.add("0x" + Integer.toHexString(s))
    return parts.joinToString("+")
}
