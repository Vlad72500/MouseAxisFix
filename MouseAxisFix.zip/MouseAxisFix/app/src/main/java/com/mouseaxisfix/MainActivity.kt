package com.mouseaxisfix

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.hardware.input.InputManager
import android.os.Bundle
import android.widget.ScrollView
import android.widget.Toast

class MainActivity : Activity(), InputManager.InputDeviceListener {

    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        scroll = ScrollView(this)
        setContentView(scroll)
        render()
    }

    override fun onResume() {
        super.onResume()
        (getSystemService(INPUT_SERVICE) as InputManager).registerInputDeviceListener(this, null)
        render()
    }

    override fun onPause() {
        super.onPause()
        (getSystemService(INPUT_SERVICE) as InputManager).unregisterInputDeviceListener(this)
    }

    override fun onInputDeviceAdded(id: Int) = render()
    override fun onInputDeviceRemoved(id: Int) = render()
    override fun onInputDeviceChanged(id: Int) = render()

    private fun render() {
        val c = column()
        val land = Cfg.landscape(this)
        val p = Cfg.profile
        val oName = if (land) "альбомного" else "портретного"

        c.addView(label("Mouse Axis Fix", 28f, 0xFFFFFFFF.toInt()))
        c.addView(label("Діагностика та налаштування осей USB-миші", 14f, 0xFF9E9E9E.toInt()))

        val m = mice()
        c.addView(label("Статус USB-миші", 13f, 0xFF8AB4F8.toInt()))
        c.addView(label(if (m.isEmpty()) "Не виявлено" else m.joinToString("\n") { "${it.name} (id ${it.id})" }, 18f))
        c.addView(label("Статус підключення", 13f, 0xFF8AB4F8.toInt()))
        c.addView(label(if (m.isEmpty()) "Миша не підключена або хаб її не віддає" else "Підключена (${m.size})", 18f))
        c.addView(label("Орієнтація дисплея", 13f, 0xFF8AB4F8.toInt()))
        c.addView(label("${orientationText()}, поворот дисплея ${displayRotationText()}", 18f))

        c.addView(label("Активний профіль", 13f, 0xFF8AB4F8.toInt()))
        c.addView(button("Профіль: ${Cfg.PROFILES[p]}") {
            pick("Профіль", Cfg.PROFILES, Cfg.profile) { Cfg.profile = it; render() }
        })
        c.addView(button("Орієнтація: ${Cfg.ORIENT_MODES[Cfg.orientMode]}") {
            pick("Вибір профілю орієнтації", Cfg.ORIENT_MODES, Cfg.orientMode) { Cfg.orientMode = it; render() }
        })

        c.addView(label("Налаштування для $oName режиму", 13f, 0xFF8AB4F8.toInt()))
        c.addView(button("Осі: ${Cfg.AXES[Cfg.axes(p, land)]}") {
            pick("Перетворення осей", Cfg.AXES, Cfg.axes(p, land)) { Cfg.setAxes(p, land, it); render() }
        })
        c.addView(button("Поворот: ${Cfg.ROTS[Cfg.rot(p, land)]}") {
            pick("Поворот координат", Cfg.ROTS, Cfg.rot(p, land)) { Cfg.setRot(p, land, it); render() }
        })

        c.addView(label(
            "⚠ Застосунок змінює рух миші лише у власній тестовій області. " +
            "На GeForce NOW і інші застосунки він без Root не впливає. " +
            "Спробуйте розділ «Експериментально».", 14f, 0xFFFFB74D.toInt()))

        c.addView(button("Тестування і діагностика") {
            startActivity(Intent(this, DiagActivity::class.java))
        })
        c.addView(button("Експериментально (поворот екрана, Shizuku)", 0xFF7B4DB5.toInt()) {
            startActivity(Intent(this, ExperimentalActivity::class.java))
        })
        c.addView(button("Зберегти", 0xFF2E8B57.toInt()) {
            Toast.makeText(this, "Збережено (зміни також зберігаються одразу)", Toast.LENGTH_SHORT).show()
        })
        c.addView(button("Скинути налаштування", 0xFFB23B3B.toInt()) {
            AlertDialog.Builder(this)
                .setTitle("Скинути всі налаштування?")
                .setPositiveButton("Скинути") { _, _ -> Cfg.reset(); render() }
                .setNegativeButton("Скасувати", null)
                .show()
        })
        scroll.removeAllViews()
        scroll.addView(c)
    }
}
