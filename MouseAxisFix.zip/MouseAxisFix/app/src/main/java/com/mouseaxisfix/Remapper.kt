package com.mouseaxisfix

import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.system.exitProcess

// Запускається через Shizuku (shell) командою app_process. НЕ є Activity.

private fun log(s: String) {
    System.out.println(s)
    System.out.flush()
}

private fun tr(dx: Float, dy: Float, axes: Int, rot: Int): FloatArray {
    var x = dx
    var y = dy
    when (axes) {
        1 -> { x = dy; y = dx }
        2 -> { x = -dx }
        3 -> { y = -dy }
        4 -> { x = -dx; y = -dy }
    }
    val ox = x
    val oy = y
    return when (rot) {
        1 -> floatArrayOf(-oy, ox)
        2 -> floatArrayOf(-ox, -oy)
        3 -> floatArrayOf(oy, -ox)
        else -> floatArrayOf(ox, oy)
    }
}

private class Injector(val rel: Boolean, val w: Int, val h: Int, val axes: Int, val rot: Int) {
    private var im: Any? = null
    private var injectM: Method? = null
    private var three = false
    private var x = w / 2f
    private var y = h / 2f
    private var buttons = 0
    private var downTime = 0L
    private val props = arrayOf(MotionEvent.PointerProperties().apply {
        id = 0
        toolType = MotionEvent.TOOL_TYPE_MOUSE
    })

    init {
        val cls = Class.forName("android.hardware.input.InputManager")
        val g = cls.getDeclaredMethod("getInstance")
        g.isAccessible = true
        im = g.invoke(null)
        try {
            injectM = cls.getMethod("injectInputEvent", InputEvent::class.java, java.lang.Integer.TYPE)
        } catch (e: Throwable) {
            injectM = cls.getMethod("injectInputEvent", InputEvent::class.java, java.lang.Integer.TYPE, java.lang.Integer.TYPE)
            three = true
        }
    }

    private fun px(): Float = if (rel) 0f else x
    private fun py(): Float = if (rel) 0f else y

    private fun make(action: Int, vx: Float, vy: Float, rx: Float, ry: Float,
                     actionButton: Int = 0, vs: Float = 0f, hs: Float = 0f): MotionEvent {
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downTime = now
        val c = MotionEvent.PointerCoords()
        c.x = vx
        c.y = vy
        c.setAxisValue(MotionEvent.AXIS_RELATIVE_X, rx)
        c.setAxisValue(MotionEvent.AXIS_RELATIVE_Y, ry)
        if (vs != 0f) c.setAxisValue(MotionEvent.AXIS_VSCROLL, vs)
        if (hs != 0f) c.setAxisValue(MotionEvent.AXIS_HSCROLL, hs)
        val src = if (rel) 0x00020004 else InputDevice.SOURCE_MOUSE
        val dt = if (buttons != 0 || action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_DOWN) downTime else now
        val ev = MotionEvent.obtain(dt, now, action, 1, props, arrayOf(c), 0, buttons, 1f, 1f, 0, 0, src, 0)
        if (actionButton != 0) ev.setActionButton(actionButton)
        return ev
    }

    private fun send(ev: MotionEvent) {
        try {
            if (three) injectM!!.invoke(im, ev, 0, -1) else injectM!!.invoke(im, ev, 0)
        } catch (t: Throwable) {
            log("inject error: " + (t.cause ?: t))
        } finally {
            ev.recycle()
        }
    }

    fun move(dx: Float, dy: Float) {
        val t = tr(dx, dy, axes, rot)
        if (rel) {
            send(make(MotionEvent.ACTION_MOVE, t[0], t[1], t[0], t[1]))
        } else {
            x = (x + t[0]).coerceIn(0f, (w - 1).toFloat())
            y = (y + t[1]).coerceIn(0f, (h - 1).toFloat())
            val a = if (buttons != 0) MotionEvent.ACTION_MOVE else MotionEvent.ACTION_HOVER_MOVE
            send(make(a, x, y, t[0], t[1]))
        }
    }

    fun button(code: Int, down: Boolean) {
        val b = when (code) {
            0x110 -> MotionEvent.BUTTON_PRIMARY
            0x111 -> MotionEvent.BUTTON_SECONDARY
            0x112 -> MotionEvent.BUTTON_TERTIARY
            0x113 -> MotionEvent.BUTTON_BACK
            0x114 -> MotionEvent.BUTTON_FORWARD
            else -> return
        }
        if (down) {
            val was = buttons
            buttons = buttons or b
            if (was == 0) send(make(MotionEvent.ACTION_DOWN, px(), py(), 0f, 0f))
            send(make(MotionEvent.ACTION_BUTTON_PRESS, px(), py(), 0f, 0f, b))
        } else {
            buttons = buttons and b.inv()
            send(make(MotionEvent.ACTION_BUTTON_RELEASE, px(), py(), 0f, 0f, b))
            if (buttons == 0) send(make(MotionEvent.ACTION_UP, px(), py(), 0f, 0f))
        }
    }

    fun scroll(v: Float, hh: Float) {
        send(make(MotionEvent.ACTION_SCROLL, px(), py(), 0f, 0f, 0, v, hh))
    }
}

private fun grab(fd: FileDescriptor) {
    val cmd = 0x40044590 // EVIOCGRAB
    val os = Class.forName("libcore.io.Libcore").getField("os").get(null)
    val m = Class.forName("libcore.io.Os").methods.first { it.name == "ioctlInt" }
    if (m.parameterTypes.size == 2) {
        m.invoke(os, fd, cmd)
    } else {
        val ref = Class.forName("android.system.Int32Ref").getConstructor(java.lang.Integer.TYPE).newInstance(1)
        m.invoke(os, fd, cmd, ref)
    }
}

private fun findDevices(vid: String?, pid: String?): List<String> {
    val res = ArrayList<String>()
    val text = File("/proc/bus/input/devices").readText()
    for (block in text.split("\n\n")) {
        var v = ""
        var p = ""
        var handlers = ""
        var ev = 0L
        for (line in block.lines()) {
            if (line.startsWith("I:")) {
                v = Regex("Vendor=([0-9a-fA-F]+)").find(line)?.groupValues?.get(1)?.lowercase() ?: ""
                p = Regex("Product=([0-9a-fA-F]+)").find(line)?.groupValues?.get(1)?.lowercase() ?: ""
            } else if (line.startsWith("H:")) {
                handlers = line
            } else if (line.startsWith("B: EV=")) {
                ev = line.removePrefix("B: EV=").trim().toLongOrNull(16) ?: 0L
            }
        }
        if (!handlers.contains("mouse")) continue
        if ((ev and 0x4L) == 0L) continue
        if (vid != null && pid != null && (v != vid.lowercase() || p != pid.lowercase())) continue
        val node = Regex("event(\\d+)").find(handlers)?.value ?: continue
        res.add("/dev/input/$node")
    }
    return res
}

fun main(args: Array<String>) {
    try {
        runRemapper(args)
    } catch (t: Throwable) {
        log("FATAL: $t")
        exitProcess(1)
    }
}

private fun runRemapper(args: Array<String>) {
    val m = HashMap<String, String>()
    for (a in args) {
        val i = a.indexOf('=')
        if (i > 0) m[a.substring(0, i)] = a.substring(i + 1)
    }
    val rel = (m["mode"] ?: "rel") == "rel"
    val w = m["w"]?.toIntOrNull() ?: 1920
    val h = m["h"]?.toIntOrNull() ?: 1080
    val axes = m["axes"]?.toIntOrNull() ?: 0
    val rot = m["rot"]?.toIntOrNull() ?: 1
    val minutes = m["minutes"]?.toLongOrNull() ?: 60L
    log("START mode=${if (rel) "rel" else "abs"} w=$w h=$h axes=$axes rot=$rot vid=${m["vid"]} pid=${m["pid"]}")

    val devs = findDevices(m["vid"], m["pid"])
    if (devs.isEmpty()) { log("FATAL: mouse device not found in /proc/bus/input/devices"); exitProcess(2) }
    log("devices: $devs")

    val inj = Injector(rel, w, h, axes, rot)
    log("injector ok")

    val streams = ArrayList<FileInputStream>()
    for (d in devs) {
        val fin = FileInputStream(d)
        try {
            grab(fin.fd)
        } catch (t: Throwable) {
            log("GRAB FAILED for $d: " + (t.cause ?: t))
            exitProcess(3)
        }
        streams.add(fin)
    }
    log("READY: grab ok")

    val is64 = android.os.Process.is64Bit()
    val sz = if (is64) 24 else 16
    val lock = Any()
    val threads = ArrayList<Thread>()
    for (fin in streams) {
        val t = Thread {
            val buf = ByteArray(sz)
            val bb = ByteBuffer.wrap(buf).order(ByteOrder.nativeOrder())
            var dx = 0
            var dy = 0
            var wv = 0
            var wh = 0
            try {
                while (true) {
                    var off = 0
                    while (off < sz) {
                        val n = fin.read(buf, off, sz - off)
                        if (n < 0) { log("device closed"); exitProcess(0) }
                        off += n
                    }
                    val type = bb.getShort(sz - 8).toInt() and 0xFFFF
                    val code = bb.getShort(sz - 6).toInt() and 0xFFFF
                    val value = bb.getInt(sz - 4)
                    synchronized(lock) {
                        when (type) {
                            2 -> when (code) {
                                0 -> dx += value
                                1 -> dy += value
                                8 -> wv += value
                                6 -> wh += value
                            }
                            1 -> if (value != 2) inj.button(code, value != 0)
                            0 -> if (code == 0) {
                                if (dx != 0 || dy != 0) { inj.move(dx.toFloat(), dy.toFloat()); dx = 0; dy = 0 }
                                if (wv != 0 || wh != 0) { inj.scroll(wv.toFloat(), wh.toFloat()); wv = 0; wh = 0 }
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
                log("reader stopped: $e")
                exitProcess(0)
            }
        }
        t.start()
        threads.add(t)
    }
    Thread {
        try { Thread.sleep(minutes * 60_000L) } catch (_: Throwable) {}
        log("timeout, exit")
        exitProcess(0)
    }.start()
    for (t in threads) t.join()
}
