package com.mouseaxisfix

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku

class ExperimentalActivity : Activity() {

    private lateinit var scroll: ScrollView
    private lateinit var out: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> ui.post { render() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        scroll = ScrollView(this)
        setContentView(scroll)
        try { Shizuku.addRequestPermissionResultListener(permListener) } catch (_: Throwable) {}
        render()
    }

    override fun onResume() { super.onResume(); render() }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener) } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun shizukuStatus(): String = try {
        if (!Shizuku.pingBinder()) "Shizuku не запущено"
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "Готово (дозвіл надано)"
        else "Shizuku запущено, дозволу немає"
    } catch (t: Throwable) { "Недоступно: ${t.javaClass.simpleName}" }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    private fun render() {
        val c = column()
        c.addView(label("Експериментально", 26f, 0xFFFFFFFF.toInt()))
        c.addView(label(
            "Ці засоби не перехоплюють мишу GeForce NOW. Вони лише пробують змінити орієнтацію " +
            "екрана/вводу, що може вплинути на те, як Android передає рух миші. " +
            "Результат залежить від пристрою, перевіряйте в діагностиці та в грі.", 14f, 0xFFFFB74D.toInt()))

        // --- Блок A: WRITE_SETTINGS
        c.addView(label("A. Блокування повороту (без Shizuku)", 18f, 0xFF8AB4F8.toInt()))
        c.addView(label("Ідея: зафіксувати іншу альбомну орієнтацію (90° або 270°) і перевірити, чи зник перекіс у GFN.", 14f))
        if (!Settings.System.canWrite(this)) {
            c.addView(button("Надати дозвіл «Змінення системних налаштувань»") {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            })
        } else {
            for (r in 0..3) {
                c.addView(button("Зафіксувати поворот ${r * 90}° (user_rotation=$r)", 0xFF2D6CDF.toInt()) { lockRotation(r) })
            }
            c.addView(button("Повернути автоповорот", 0xFF555555.toInt()) { autoRotation() })
        }

        // --- Блок B: Shizuku
        c.addView(label("B. Shizuku (потрібен запущений Shizuku)", 18f, 0xFF8AB4F8.toInt()))
        c.addView(label(
            "Запуск Shizuku без ПК: встановіть Shizuku, увімкніть «Бездротове налагодження» і " +
            "запустіть його в самому застосунку Shizuku.", 14f))
        c.addView(label("Статус: ${shizukuStatus()}", 16f))
        c.addView(button("Запросити дозвіл Shizuku") {
            try { Shizuku.requestPermission(100) } catch (t: Throwable) { show("Помилка: ${t.message}") }
        })
        c.addView(button("Оновити статус", 0xFF555555.toInt()) { render() })
        val cmds = listOf(
            "wm user-rotation lock 1" to "Shell: зафіксувати 90°",
            "wm user-rotation lock 3" to "Shell: зафіксувати 270°",
            "wm user-rotation free" to "Shell: вільний поворот",
            "input mouse swipe 400 400 700 400 300" to "Тест інʼєкції: свайп мишею вправо",
            "dumpsys input | head -c 3500" to "Діагностика: dumpsys input (фрагмент)"
        )
        for ((cmd, name) in cmds) {
            c.addView(button(name, 0xFF7B4DB5.toInt()) { runShizuku(cmd) })
        }
        out = label("", 12f, 0xFFB0B0B0.toInt())
        out.typeface = android.graphics.Typeface.MONOSPACE
        c.addView(out)
        scroll.removeAllViews()
        scroll.addView(c)
    }

    private fun lockRotation(r: Int) {
        try {
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.USER_ROTATION, r)
            show("Поворот зафіксовано: ${r * 90}°. Запустіть GFN і перевірте.")
        } catch (t: Throwable) { show("Помилка: ${t.message}") }
    }

    private fun autoRotation() {
        try {
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            show("Автоповорот увімкнено.")
        } catch (t: Throwable) { show("Помилка: ${t.message}") }
    }

    private fun show(s: String) { ui.post { if (::out.isInitialized) out.text = s } }

    private fun runShizuku(cmd: String) {
        if (!shizukuReady()) { show("Shizuku не готовий (див. статус)."); return }
        show("Виконується: $cmd")
        Thread {
            val res = try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                m.isAccessible = true
                val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
                val o = p.inputStream.bufferedReader().readText()
                val e = p.errorStream.bufferedReader().readText()
                val code = p.waitFor()
                "exit=$code\n" + o.take(3500) + (if (e.isNotEmpty()) "\n[stderr]\n" + e.take(1000) else "")
            } catch (t: Throwable) {
                "Помилка: ${t.javaClass.simpleName}: ${t.message}"
            }
            show(res)
        }.start()
    }
}
