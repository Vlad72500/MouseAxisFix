package com.mouseaxisfix

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.ArrayDeque
import java.util.Locale

class DiagActivity : Activity() {

    private lateinit var info: TextView
    private lateinit var logTv: TextView
    private lateinit var view: MouseTestView
    private lateinit var capBtn: android.widget.Button
    private val lines = ArrayDeque<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var last: MouseTestView.Evt? = null
    private var scheduled = false
    private var captured = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

        view = MouseTestView(this)
        view.transform = { dx, dy ->
            val l = Cfg.landscape(this)
            val p = Cfg.profile
            Cfg.transform(dx, dy, Cfg.axes(p, l), Cfg.rot(p, l))
        }
        view.onEvt = { e -> onEvent(e) }

        info = label("Рухайте мишею по темній області", 14f)
        logTv = label("", 12f, 0xFFB0B0B0.toInt())
        logTv.typeface = android.graphics.Typeface.MONOSPACE
        capBtn = button("Захопити курсор (relative-режим)") { toggleCapture() }
        val clear = button("Очистити журнал", 0xFF555555.toInt()) { lines.clear(); logTv.text = "" }

        val panel = column()
        panel.addView(info)
        panel.addView(capBtn)
        panel.addView(clear)
        val sv = ScrollView(this)
        sv.addView(logTv)
        panel.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val root = LinearLayout(this)
        root.orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        root.addView(view, LinearLayout.LayoutParams(if (land) 0 else -1, if (land) -1 else 0, 1f))
        root.addView(panel, LinearLayout.LayoutParams(if (land) 0 else -1, if (land) -1 else 0, 1f))
        setContentView(root)
        refreshInfo()
    }

    private fun toggleCapture() {
        if (captured) view.releasePointerCapture() else { view.requestFocus(); view.requestPointerCapture() }
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {
        captured = hasCapture
        capBtn.text = if (hasCapture) "Відпустити курсор" else "Захопити курсор (relative-режим)"
    }

    private fun onEvent(e: MouseTestView.Evt) {
        last = e
        lines.addLast(String.format(Locale.US, "%s %s dx=%.1f dy=%.1f → %.1f %.1f", e.kind, e.src, e.dx, e.dy, e.tx, e.ty))
        while (lines.size > 60) lines.removeFirst()
        if (!scheduled) {
            scheduled = true
            handler.postDelayed({
                scheduled = false
                logTv.text = lines.reversed().joinToString("\n")
                refreshInfo()
            }, 80)
        }
    }

    private fun refreshInfo() {
        val l = Cfg.landscape(this)
        val p = Cfg.profile
        val sb = StringBuilder()
        val m = mice()
        sb.append("USB-пристрій: ").append(if (m.isEmpty()) "не знайдено" else m.joinToString { it.name }).append('\n')
        m.firstOrNull()?.let {
            sb.append("  vendor=${it.vendorId} product=${it.productId} sources=${sourceName(it.sources)}\n")
        }
        sb.append("Орієнтація: ").append(orientationText()).append(", дисплей ").append(displayRotationText()).append('\n')
        sb.append("Профіль: ").append(Cfg.PROFILES[p]).append(" / ").append(if (l) "альбом" else "портрет").append('\n')
        sb.append("Осі: ").append(Cfg.AXES[Cfg.axes(p, l)]).append(", поворот: ").append(Cfg.ROTS[Cfg.rot(p, l)]).append('\n')
        last?.let {
            sb.append("Джерело: ").append(it.src).append(" (").append(it.dev).append(")\n")
            sb.append(String.format(Locale.US, "X/Y: %.1f / %.1f\n", it.x, it.y))
            sb.append(String.format(Locale.US, "dx/dy сирі: %.1f / %.1f\n", it.dx, it.dy))
            sb.append(String.format(Locale.US, "dx/dy після: %.1f / %.1f", it.tx, it.ty))
        }
        info.text = sb.toString()
    }
}
