package com.mouseaxisfix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class MouseTestView(ctx: Context) : View(ctx) {

    class Evt(
        val kind: String, val src: String, val dev: String,
        val x: Float, val y: Float,
        val dx: Float, val dy: Float, val tx: Float, val ty: Float
    )

    var transform: (Float, Float) -> Pair<Float, Float> = { x, y -> Pair(x, y) }
    var onEvt: (Evt) -> Unit = {}

    private var lastX = 0f
    private var lastY = 0f
    private var has = false
    private var absX = 0f
    private var absY = 0f
    private var rawDx = 0f
    private var rawDy = 0f
    private var trDx = 0f
    private var trDy = 0f

    private val gray = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9E9E9E.toInt(); strokeWidth = 6f }
    private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF4CAF50.toInt(); strokeWidth = 10f }
    private val grid = Paint().apply { color = 0xFF333333.toInt(); strokeWidth = 2f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 32f }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setOnCapturedPointerListener { _, e -> handle(e, true); true }
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(android.view.InputDevice.SOURCE_MOUSE)) {
            if (e.actionMasked == MotionEvent.ACTION_HOVER_EXIT) { has = false; return true }
            if (e.actionMasked == MotionEvent.ACTION_HOVER_MOVE || e.actionMasked == MotionEvent.ACTION_MOVE) {
                handle(e, false); return true
            }
        }
        return super.onGenericMotionEvent(e)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(android.view.InputDevice.SOURCE_MOUSE)) {
            if (e.actionMasked == MotionEvent.ACTION_MOVE) handle(e, false)
            return true
        }
        return true
    }

    private fun handle(e: MotionEvent, relative: Boolean) {
        val dx: Float
        val dy: Float
        if (relative) {
            dx = e.x; dy = e.y
            absX += dx; absY += dy
        } else {
            absX = e.x; absY = e.y
            if (has) { dx = e.x - lastX; dy = e.y - lastY } else { dx = 0f; dy = 0f }
            lastX = e.x; lastY = e.y; has = true
        }
        if (dx == 0f && dy == 0f) return
        val t = transform(dx, dy)
        rawDx = dx; rawDy = dy; trDx = t.first; trDy = t.second
        val name = e.device?.name ?: "?"
        val kind = (if (relative) "REL " else "") + MotionEvent.actionToString(e.actionMasked).removePrefix("ACTION_")
        onEvt(Evt(kind, sourceName(e.source), name, absX, absY, dx, dy, t.first, t.second))
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF1B1B1B.toInt())
        val cx = width / 2f
        val cy = height / 2f
        c.drawLine(0f, cy, width.toFloat(), cy, grid)
        c.drawLine(cx, 0f, cx, height.toFloat(), grid)
        c.drawText("↑ верх екрана", cx - 90f, 40f, txt)
        arrow(c, cx, cy, rawDx, rawDy, gray)
        arrow(c, cx, cy, trDx, trDy, green)
        c.drawText("сірий = сирий рух, зелений = після перетворення", 16f, height - 16f, txt.apply { textSize = 24f })
    }

    private fun arrow(c: Canvas, cx: Float, cy: Float, vx: Float, vy: Float, p: Paint) {
        val len = hypot(vx, vy)
        if (len == 0f) return
        val l = (len * 10f).coerceIn(30f, minOf(width, height) / 2.2f)
        val a = atan2(vy, vx)
        val ex = cx + cos(a) * l
        val ey = cy + sin(a) * l
        c.drawLine(cx, cy, ex, ey, p)
        for (s in floatArrayOf(2.6f, -2.6f)) {
            c.drawLine(ex, ey, ex + cos(a + s) * 28f, ey + sin(a + s) * 28f, p)
        }
    }
}
